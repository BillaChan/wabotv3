Botwasap v3

Bayak yang baru
Check aja sendiri

|-----------------|

lots of updates
Just check it yourself 
If you can help me to translate the bot language please chat me in whatsapp

|-----------------|

My whatsapp
wa.me/6282334297175

My Instagram
https://Instagram.com/affis_saputro123
